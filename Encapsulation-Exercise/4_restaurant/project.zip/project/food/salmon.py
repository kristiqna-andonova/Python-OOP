from project.food.main_dish import MainDish


class Salmon(MainDish):
    pass
